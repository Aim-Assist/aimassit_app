// Generic Text
const String tLogin = "Login";
const String tSignUp = "Sign Up";

// Welcome Screen Text
const String tWelcomeTitle = 'Build Awesome Apps';
const String tWelcomeSubtitle = "Let's put your creativity on the development highway.";


// -- Login Screen Text
const String tLoginTitle = 'Welcome Back,';
const String tLoginSubTitle = 'Make it work, make it right, make it fast';
const String tRememberMe = 'Remember Me';
const String tAlreadyHaveAnAccount = 'Already have an account';
const String tEmail = 'Email';
const String tpassword = 'Password';
const String tForgetPassword = "Forget Password";
const String tSignInWithGoogle = "Sign-In with Google";
const String tDontHaveAnAccount = "Don't Have an Account ? ";


// Sign up Screen
const String tSignUpTitle = "Get On Board";
const String tSignUpSubTitle = "Create Your AimAssit Profile";
const String tFullName = 'Full Name';
const String tPhoneNo = 'Phone Number';