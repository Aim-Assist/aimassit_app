

const String tWelcomeImage = 'assets/images/welcome_screen.png';

const String tGoogleLogoImage = 'assets/images/googlelogo.png';